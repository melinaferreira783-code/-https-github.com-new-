# One Language — projeto Android

- Nome: One Language
- Identificador Android: `com.onelanguage.app`
- Versão: `1.0.0` (versionCode 1)
- SDK de compilação/alvo: API 36
- Conteúdo: curso de inglês; interface em português
- Arquivo principal do app: `app/src/main/assets/index.html`

## Gerar os arquivos pelo GitHub usando o celular

Este projeto inclui um fluxo automático do GitHub Actions. Ele compila:
- `app-debug.apk`: para instalar e testar no seu Android.
- `app-release.aab`: pacote Android App Bundle ainda **sem assinatura de publicação**.

Passos:
1. Crie um repositório novo no GitHub chamado `OneLanguage` (não use o repositório de outro aplicativo).
2. Extraia este ZIP e envie o conteúdo da pasta `OneLanguageAndroid` para a raiz do repositório. A pasta `.github/workflows` também precisa ser enviada.
3. No GitHub, abra o repositório e entre em **Actions**.
4. Se aparecer a opção, confirme **I understand my workflows, go ahead and enable them**.
5. Abra **Gerar One Language para Android** e toque em **Run workflow**.
6. Aguarde terminar com marca verde. Abra a execução e baixe o item **OneLanguage-Android** em **Artifacts**.
7. Dentro do ZIP baixado estarão o APK de teste e o AAB.

## Importante sobre a publicação

- O APK de teste é compilado em modo debug; serve para instalar e testar, não para publicar.
- O AAB produzido nesta primeira compilação é sem assinatura de publicação. A Google Play exige um AAB assinado com uma chave de upload. A chave deve ser criada e guardada por você em local seguro; nunca publique o arquivo da chave no repositório.
- Não compartilhe senhas ou arquivos de chave nesta conversa.
- O app ainda precisa ser testado em aparelho real. O reconhecimento de fala no WebView depende do suporte do Android/WebView e do serviço de voz do aparelho; a permissão do microfone, sozinha, não garante que o reconhecimento funcione.
- Perfis e progresso ficam no armazenamento local do app; não há contas com sincronização em servidor neste projeto.
- Antes do envio à Play Store, preencha política de privacidade, Segurança dos dados, classificação indicativa, público-alvo e demais declarações exigidas pela Play Console.

## Configurações Android

- `applicationId`: `com.onelanguage.app`
- `minSdk`: 23
- `targetSdk`: 36
- `versionCode`: 1
- `versionName`: `1.0.0`
